﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClgProject.InternsFile.Model
{
    class InternLeaveReason
    {
        public string reason { get; set; }
        public string date { get; set; }
        public string typeofleave { get; set; }
        public string seperatordate { get; set; }
        public string statusofleave { get; set; }
        public string buttontext { get; set; }
    }
}